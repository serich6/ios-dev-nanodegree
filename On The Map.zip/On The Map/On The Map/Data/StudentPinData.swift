//
//  StudentPinData.swift
//  On The Map
//
//  Created by Sam Rich on 6/11/19.
//  Copyright © 2019 Sam Rich. All rights reserved.
//

import Foundation

class StudentPinData {
    static var pins = [StudentInformation]()
}
