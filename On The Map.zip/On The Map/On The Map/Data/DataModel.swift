//
//  DataModel.swift
//  On The Map
//
//  Created by Sam Rich on 6/11/19.
//  Copyright © 2019 Sam Rich. All rights reserved.
//

import Foundation

class DataModel {
    static var userPinAddedForSession = false
    static var user = UserData()
    static var pinData = [StudentInformation]()
    
}
